$(()=>{ 
    //renderMap();
    var map = getJson();
    console.log(map);
    hatchMap();


});