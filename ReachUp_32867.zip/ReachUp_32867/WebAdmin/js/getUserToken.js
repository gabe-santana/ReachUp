$document.ready(function(){
      return sessionStorage.getItem('token');
      //Arquivo ainda não utilizado
})