class PageBase {
    commonProperty: any;

    constructor(doc: HTMLDocument) {
        return;
    }
}