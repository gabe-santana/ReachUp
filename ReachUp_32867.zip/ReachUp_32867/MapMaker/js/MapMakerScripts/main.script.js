$(()=>{ 
    var map = getJson();
    console.log(map);
    setMapLength();
    renderMap();
});