$(()=>{ 
    //renderMap();
    var map = getJson();
    console.log(map);
    renderMap();
});

/*$(function(){
    renderMap();
    var map = getJson();
    console.log(map);


});*/